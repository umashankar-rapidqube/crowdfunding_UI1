import Ember from 'ember';
export default Ember.Controller.extend( {
    // Used only for time series chart
   /* content: [ {
        label: "New Campaigns", value: 10, type: "total"
    }
    , {
        label: "Closed Campaigns", value: 20, type: "total"
    }
    , {
        label: "In-Progress Campaigns", value: 9, type: "total"
    }
    , {
        label: "Approved Bids", value: 15, type: "total"
    }
    , {
        label: "Total Fund Initiated", value: 5, type: "total"
    }
    , {
        label: "Total Fund Received", value: 10, type: "total"
    }
    ]*/
}

);